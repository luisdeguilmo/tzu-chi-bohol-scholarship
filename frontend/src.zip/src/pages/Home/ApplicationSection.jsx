import ApplicationForm from "./ApplicationForm";

export default function ApplicationSection() {
    return (
        <div className="py-5">
            <ApplicationForm />
        </div>
    );
}

// const [personalInfo, setPersonalInfo] = useState({
//     lastName: "",
//     firstName: "",
//     middleName: "",
//     suffix: "",
//     gender: ["Male", "Female"],
//     age: "",
//     birthDate: "",
//     birthPlace: "",
//     homeAddress: "",
//     subdVillage: "",
//     barangay: "",
//     cityMunicipality: "",
//     zipcode: "",
//     personalContact: "",
//     secondaryContact: "",
//     religion: "",
//     civilStatus: "",
//     facebook: "",
//     emailAddress: "",
// });

// const [educationalBackground, setEducationalBackground] = useState({
//     lastSchoolAttended: "",
//     lastSchoolLocation: "",
//     honorAward: "",
//     gwa: "",
//     courseTaken: "",
//     incomingGradeYearLevel: ["JHS", "SHS", "College", "Vocational"],
//     school: "",
//     newSchoolLocation: "",
//     firstCourse: "",
//     secondCourse: "",
// });

// const [familyInfo, setFamilyInfo] = useState({
//     fatherName: "",
//     fatherAge: "",
//     fatherEduAttainment: "",
//     fatherOccupation: "",
//     fatherMonthlyIncome: "",
//     fatherContactNumber: "",
//     motherName: "",
//     motherAge: "",
//     motherEduAttainment: "",
//     motherOccupation: "",
//     motherMonthlyIncome: "",
//     motherContactNumber: "",
//     guardianName: "",
//     guardianAge: "",
//     guardianEduAttainment: "",
//     guardianOccupation: "",
//     guardianMonthlyIncome: "",
//     guardianContactNumber: "",
//     contactPerson: {
//         name: "",
//         relationship: "",
//         address: "",
//         contactNo: "",
//     },
// });

// const [familyMembers, setFamilyMembers] = useState([
//     {
//         name: "",
//         relationship: "",
//         age: "",
//         gender: "",
//         civilStatus: "",
//         livingWithFamily: "",
//         educationOccupation: "",
//         income: "",
//     },
// ]);

// const [siblings, setSiblings] = useState([
//     { name: "", yearLevel: "", school: "", course: "" },
// ]);