import Accordion from "./Accordion";

function ScholarshipInfo() {
    return (
        <section className="px-5 py-8 bg-gray-100">
            <h2 className="mb-8 font-semibold text-2xl text-center">Scholarship Information</h2>
            <div className="max-w-[800px] mx-auto">
                <Accordion />
            </div>
        </section>
    );
}

export default ScholarshipInfo;