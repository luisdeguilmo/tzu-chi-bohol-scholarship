import React, { useState } from "react";

function Accordion() {
    // State to track the currently open accordion
    const [openAccordionIndex, setOpenAccordionIndex] = useState(null);

    const toggleAccordion = (index) => {
        // If the clicked accordion is already open, close it
        if (openAccordionIndex === index) {
            setOpenAccordionIndex(null);
        } else {
            // Otherwise, open the clicked accordion
            setOpenAccordionIndex(index);
        }
    };

    const tableStyle = "border-[1px] border-gray-800 p-2";

    const requirementsData = [
        {
            quantity: "1 CTC from your school",
            description: "Previous Report Card",
            submit: "Application"
        },
        {
            quantity: "1 Original Copy",
            description: "Barangay Certificate of Indigency",
            submit: "Examination"
        },
        {
            quantity: "1 CTC from your school",
            description: "Good Moral Certificate",
            submit: "Interview"
        },
        {
            quantity: "1 Photocopy",
            description: "Both Parent or Guardian Latest BIR Income Tax Return Form 1700 or BIR Certificate of Exemption Form 2304 (if working) and Affidavit of Non-Filling of Income Tax Return of both parents (if not working)",
            submit: "Case Visitation"
        },
        {
            quantity: "1 Whole Bond Paper",
            description: "Type Written Personal Autobiography (minimum of 500 words)",
            submit: "Examination"
        },
        {
            quantity: "2 Photocopy",
            description: "Utility Bills (Electric, Water, etc.) with Family address",
            submit: "Case Visitation"
        },
        {
            quantity: "1 Original Copy",
            description: "PSA Birth Certificate",
            submit: "Application"
        },
        {
            quantity: "2 Pieces",
            description: "Latest 1x1 Picture with White Background (not , not cut)",
            submit: "Application"
        },
    ];

    const accordionData = [
        {
            id: 1,
            title: "Qualifications",
            content: (
                <ul className="list-disc list-inside">
                    <li>
                        K12 graduate (Incoming 1st-year college this school
                        year).
                    </li>
                    <li>
                        Belongs to <strong>INDIGENT FAMILY</strong> certified by
                        the Barangay Captain.
                    </li>
                    <li>The family is residing in Bohol.</li>
                    <li>Single.</li>
                    <li>Good moral standing in school and community.</li>
                    <li>
                        GWA of 2.5% (82%) with no failing grades in any
                        subjects.
                    </li>
                    <li>
                        Already taken or already passed the entrance examination
                        in the Campuses mentioned above.
                    </li>
                </ul>
            ),
        },
        {
            id: 2,
            title: "Requirements",
            content: (
                <table className={`${tableStyle}`}>
                    <thead>
                        <tr className={tableStyle}>
                            <th colSpan={3} className={tableStyle}>Requirements</th>
                        </tr>
                        <tr className={tableStyle}>
                            <th className={tableStyle}>
                                Quantity
                            </th>
                            <th className={tableStyle}>
                                Description
                            </th>
                            <th className={tableStyle}>
                                Submit
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        {requirementsData.map((data, index) => 
                            <tr key={index} className={tableStyle}>
                                <td className={tableStyle}>{data.quantity}</td>
                                <td className={tableStyle}>{data.description}</td>
                                <td className={tableStyle}>{data.submit}</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            ),
        },
        {
            id: 3,
            title: "Procedure",
            content: (
                <ul className="list-disc list-inside">
                    <li>Filling out the Application Form</li>
                    <li>Compiling of Requirements</li>
                    <li>Entrance Examination</li>
                    <li>Initial Interview with the Applicant</li>
                    <li>Home Visitation</li>
                    <li>
                        Final Interview with the Parent together with the
                        applicant
                    </li>
                    <li>Orientation</li>
                </ul>
            ),
        },
    ];

    return (
        <div className="max-w-[800px] mx-auto mt-[3px]">
            {accordionData.map((accordion, index) => (
                <div key={accordion.id} className="mb-[3px]">
                    <label
                        htmlFor={`criteria-${accordion.id}`}
                        className="flex items-center justify-between p-5 cursor-pointer text-white font-bold bg-green-600 rounded-sm"
                        onClick={() => toggleAccordion(index)}
                    >
                        {accordion.title}
                        <span className="material-symbols-outlined">
                            {openAccordionIndex === index
                                ? "stat_1"
                                : "stat_minus_1"}
                        </span>
                    </label>
                    <div
                        className={`h-0 p-0 overflow-hidden ${
                            openAccordionIndex === index
                                ? "h-auto p-10 overflow-visible"
                                : ""
                        } transition-all duration-300 bg-gray-100`}
                    >
                        {accordion.content}
                    </div>
                </div>
            ))}
        </div>
    );
}

export default Accordion;
