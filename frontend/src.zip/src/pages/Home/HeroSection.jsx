import { useNavigate } from "react-router-dom";
import "/src/background.css";

function HeroSection() {
    const navigate = useNavigate();
    
    return (
        <section className="hero relative h-screen text-white">
            <div className="absolute top-[40%] left-[50%] translate-x-[-50%] translate-y-[-50%]">
                <div>
                    <h1 className="text-6xl italic font-semibold text-center whitespace-pre-wrap">
                        Seize the Opportunity, Apply Now!
                    </h1>
                    <div className="mt-5 flex justify-center gap-5">
                        <button
                            onClick={() => navigate("/application")}
                            className="w-28 p-2 text-white bg-green-600 rounded-sm"
                        >
                            Apply Now
                        </button>
                        <button className="w-28 p-2 border border-green-500 rounded-sm">
                            Login
                        </button>
                    </div>
                </div>
                <div className="mt-10">
                    <p className="text-center text-lg">
                        "Get ready! The Tzu Chi Foundation Bohol Scholarship
                        Application for S.Y. 2024-2025 will open soon."
                    </p>
                </div>
            </div>
        </section>
    );
}

export default HeroSection;
