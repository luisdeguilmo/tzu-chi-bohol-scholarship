import { useState } from "react";

const FamilyList = () => {
    const [familyMembers, setFamilyMembers] = useState([]);
    const [tzuChiScholars, setTzuChiScholars] = useState([]);
    const [assistanceList, setAssistanceList] = useState([]);

    const [newMember, setNewMember] = useState({
        name: "",
        relationship: "",
        age: "",
        gender: "",
        civilStatus: "",
        livingWithFamily: "",
        educationOrOccupation: "",
        monthlyIncome: "",
    });

    const [newScholar, setNewScholar] = useState({
        name: "",
        yearLevel: "",
        school: "",
        course: "",
    });

    const [newAssistance, setNewAssistance] = useState({
        organization: "",
        type: "",
        amount: "",
    });

    // Handle input changes
    const handleChange = (e) => {
        setNewMember({ ...newMember, [e.target.name]: e.target.value });
    };

    const handleScholarChange = (e) => {
        setNewScholar({ ...newScholar, [e.target.name]: e.target.value });
    };

    const handleAssistanceChange = (e) => {
        setNewAssistance({ ...newAssistance, [e.target.name]: e.target.value });
    };

    // Add new family member
    const addFamilyMember = () => {
        if (newMember.name && newMember.age) {
            setFamilyMembers([...familyMembers, newMember]);
            setNewMember({
                name: "",
                relationship: "",
                age: "",
                gender: "",
                civilStatus: "",
                livingWithFamily: "Yes",
                educationOrOccupation: "",
                monthlyIncome: "",
            });
        }
    };

    // Add new Tzu Chi scholar
    const addScholar = () => {
        if (newScholar.name && newScholar.school) {
            setTzuChiScholars([...tzuChiScholars, newScholar]);
            setNewScholar({
                name: "",
                yearLevel: "",
                school: "",
                course: "",
            });
        }
    };

    // Add new Assistance Entry
    const addAssistance = () => {
        if (newAssistance.organization && newAssistance.type) {
            setAssistanceList([...assistanceList, newAssistance]);
            setNewAssistance({
                organization: "",
                type: "",
                amount: "",
            });
        }
    };

    // Sort members by age (eldest to youngest)
    const sortedFamily = [...familyMembers].sort((a, b) => b.age - a.age);

    return (
        <div>
            <h2 className="pt-12 pb-6 font-bold mb-4">
                Siblings (Eldest to Youngest) including Family Member
            </h2>

            {/* Family Members Input Form */}
            <div>
                <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-5 sm:gap-4">
                    {[
                        "name",
                        "relationship",
                        "age",
                        "gender",
                        "civilStatus",
                        "educationOrOccupation",
                        "monthlyIncome",
                    ].map((field) => (
                        <input
                            key={field}
                            type={
                                field === "age" || field === "monthlyIncome"
                                    ? "number"
                                    : "text"
                            }
                            name={field}
                            value={newMember[field]}
                            onChange={handleChange}
                            placeholder={field
                                .replace(/([A-Z])/g, " $1")
                                .replace(/^./, (str) => str.toUpperCase())}
                            className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                        />
                    ))}

                    <div className="block relative">
                        <label
                            htmlFor="living"
                            className="absolute top-[-10px] text-gray-600 text-sm"
                        >
                            Status
                        </label>
                        <select
                            id="living"
                            name="livingWithFamily"
                            value={newMember.livingWithFamily}
                            onChange={handleChange}
                            className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                        >
                            <option value="" disabled>
                                Select
                            </option>
                            <option value="Yes">Living with Family</option>
                            <option value="No">Not Living with Family</option>
                        </select>
                    </div>
                </div>
                <button
                    type="button"
                    onClick={addFamilyMember}
                    className="col-span-3 my-7 shadow-lg bg-green-500 text-white p-2 rounded-sm"
                >
                    Add Member
                </button>
            </div>

            {/* Family Members Table */}
            <div className="overflow-scroll">
                {sortedFamily.length > 0 && (
                    <table className="w-full border-collapse border border-gray-300 mb-6">
                        <thead>
                            <tr className="bg-gray-200">
                                {[
                                    "Name",
                                    "Relationship",
                                    "Age",
                                    "Gender",
                                    "Civil Status",
                                    "Living?",
                                    "Education/Job",
                                    "Income",
                                ].map((header) => (
                                    <th key={header} className="border p-2">
                                        {header}
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {sortedFamily.map((member, index) => (
                                <tr key={index} className="border">
                                    <td className="border p-2">
                                        {member.name}
                                    </td>
                                    <td className="border p-2">
                                        {member.relationship}
                                    </td>
                                    <td className="border p-2">{member.age}</td>
                                    <td className="border p-2">
                                        {member.gender}
                                    </td>
                                    <td className="border p-2">
                                        {member.civilStatus}
                                    </td>
                                    <td className="border p-2">
                                        {member.livingWithFamily}
                                    </td>
                                    <td className="border p-2">
                                        {member.educationOrOccupation}
                                    </td>
                                    <td className="border p-2">
                                        {member.monthlyIncome}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>

            {/* Tzu Chi Scholars Section */}
            <h2 className="pt-12 pb-6 font-bold mb-4">
                Siblings Enjoying/Enjoyed Tzu Chi Educational Assistance
            </h2>
            <div>
                <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-5 sm:gap-4">
                    {["name", "yearLevel", "school", "course"].map((field) => (
                        <input
                            key={field}
                            type="text"
                            name={field}
                            value={newScholar[field]}
                            onChange={handleScholarChange}
                            placeholder={field
                                .replace(/([A-Z])/g, " $1")
                                .replace(/^./, (str) => str.toUpperCase())}
                            className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                        />
                    ))}
                </div>
                <button
                    type="button"
                    onClick={addScholar}
                    className="col-span-3 my-7 shadow-lg bg-green-500 text-white p-2 rounded-sm"
                >
                    Add Scholar
                </button>
            </div>

            {/* Display Scholars in a Table */}
            <div className="overflow-scroll">
                {tzuChiScholars.length > 0 && (
                    <table className="w-full border-collapse border border-gray-300">
                        <thead>
                            <tr className="bg-gray-200">
                                {["Name", "Year Level", "School", "Course"].map(
                                    (header) => (
                                        <th key={header} className="border p-2">
                                            {header}
                                        </th>
                                    )
                                )}
                            </tr>
                        </thead>
                        <tbody>
                            {tzuChiScholars.map((scholar, index) => (
                                <tr key={index} className="border">
                                    <td className="border p-2">
                                        {scholar.name}
                                    </td>
                                    <td className="border p-2">
                                        {scholar.yearLevel}
                                    </td>
                                    <td className="border p-2">
                                        {scholar.school}
                                    </td>
                                    <td className="border p-2">
                                        {scholar.course}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>

            {/* Assistance from Other Organizations */}
            <h2 className="pt-12 pb-6 font-bold">
                Assistance from Other Association, Organization, School
                Discount, etc.
            </h2>
            <div>
                <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-5 sm:gap-4">
                    {["organization", "type", "amount"].map((field) => (
                        <input
                            key={field}
                            type={field === "amount" ? "number" : "text"}
                            name={field}
                            value={newAssistance[field]}
                            onChange={handleAssistanceChange}
                            placeholder={field
                                .replace(/([A-Z])/g, " $1")
                                .replace(/^./, (str) => str.toUpperCase())}
                            className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                        />
                    ))}
                </div>
                <button
                    type="button"
                    onClick={addAssistance}
                    className="col-span-3 my-7 shadow-lg bg-green-500 text-white p-2 rounded-sm"
                >
                    Add Assistance
                </button>
            </div>

            {/* Assistance Table */}
            <div className="overflow-scroll">
                {assistanceList.length > 0 && (
                    <table className="w-full border-collapse border border-gray-300">
                        <thead>
                            <tr className="bg-gray-200">
                                {[
                                    "Organization",
                                    "Type of Support",
                                    "Amount",
                                ].map((header) => (
                                    <th key={header} className="border p-2">
                                        {header}
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {assistanceList.map((assistance, index) => (
                                <tr key={index} className="border">
                                    <td className="border p-2">
                                        {assistance.organization}
                                    </td>
                                    <td className="border p-2">
                                        {assistance.type}
                                    </td>
                                    <td className="border p-2">
                                        {assistance.amount}
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                )}
            </div>
        </div>
    );
};

function ApplicationForm() {
    // State to track the current step
    const [currentStep, setCurrentStep] = useState(1);
    // Total number of steps in the form
    const totalSteps = 5;

    // Application details state
    const [applicationDetails, setApplicationDetails] = useState({
        status: "",
        sy: "",
        caseNo: "",
    });

    // Personal information state
    const [personalInfo, setPersonalInfo] = useState({
        lastName: "",
        firstName: "",
        middleName: "",
        suffix: "",
        gender: "",
        age: "",
        birthdate: "",
        birthplace: "",
        homeAddress: "",
        subdivisionVillage: "",
        barangay: "",
        cityMunicipality: "",
        zipcode: "",
        personalContact: "",
        secondaryContact: "",
        religion: "",
        civilStatus: "",
        facebook: "",
        emailAddress: "",
    });

    const [educationalBackground, setEducationalBackground] = useState({
        lastSchoolAttended: "",
        lastSchoolLocation: "",
        honorAward: "",
        gwa: "",
        courseTaken: "",
        incomingGradeYearLevel: "Select",
        school: "",
        newSchoolLocation: "",
        firstCourse: "",
        secondCourse: "",
    });

    const [familyInfo, setFamilyInfo] = useState({
        fatherName: "",
        fatherAge: "",
        fatherEduAttainment: "",
        fatherOccupation: "",
        fatherMonthlyIncome: "",
        fatherContactNumber: "",
        motherName: "",
        motherAge: "",
        motherEduAttainment: "",
        motherOccupation: "",
        motherMonthlyIncome: "",
        motherContactNumber: "",
        guardianName: "",
        guardianAge: "",
        guardianEduAttainment: "",
        guardianOccupation: "",
        guardianMonthlyIncome: "",
        guardianContactNumber: "",
    });

    const [contactPerson, setContactPerson] = useState({
        name: "",
        relationship: "",
        address: "",
        contactNo: "",
    });

    // Handle dropdown change for application details
    const handleAppDetailsDropDown = (event) => {
        const { name, value } = event.target;
        setApplicationDetails({ ...applicationDetails, [name]: value });
    };

    // Handle input change for application details
    const handleAppDetailsChange = (e) => {
        const { name, value } = e.target;
        setApplicationDetails({ ...applicationDetails, [name]: value });
    };

    // Handle dropdown change for personal info
    const handlePersonalInfoDropDown = (event) => {
        const { name, value } = event.target;
        setPersonalInfo({ ...personalInfo, [name]: value });
    };

    // Handle input change for personal info
    const handlePersonalInfoChange = (e) => {
        const { name, value } = e.target;
        setPersonalInfo({ ...personalInfo, [name]: value });
    };

    const handleEduBackgroundDropDown = (event) => {
        const { name, value } = event.target;
        setEducationalBackground({ ...educationalBackground, [name]: value });
    };

    // Handle input change for personal info
    const handleEduBackgroundChange = (e) => {
        const { name, value } = e.target;
        setEducationalBackground({ ...educationalBackground, [name]: value });
    };

    const handleFamilyInfoDropDown = (event) => {
        const { name, value } = event.target;
        setFamilyInfo({ ...familyInfo, [name]: value });
    };

    // Handle input change for personal info
    const handleFamilyInfoChange = (e) => {
        const { name, value } = e.target;
        setFamilyInfo({ ...familyInfo, [name]: value });
    };

    // Handle input change for personal info
    const handleContactPersonChange = (e) => {
        const { name, value } = e.target;
        setContactPerson({ ...contactPerson, [name]: value });
    };

    // Go to next step
    const nextStep = (e) => {
        e.preventDefault();
        setCurrentStep(currentStep + 1);
    };

    // Go to previous step
    const prevStep = (e) => {
        e.preventDefault();
        setCurrentStep(currentStep - 1);
    };

    // Handle final form submission
    const handleSubmit = (e) => {
        e.preventDefault();
        const formData = {
            applicationDetails,
            personalInfo,
            educationalBackground,
            familyInfo,
            contactPerson,
        };
        console.log(`Form Submitted:\n${JSON.stringify(formData, null, 2)}`);
        // Here you would typically send the data to your backend
    };

    // Progress indicator component
    const ProgressIndicator = () => {
        return (
            <div className="w-[80%] lg:w-[65%] mx-auto mb-8 mt-6">
                <div className="relative flex items-center justify-between">
                    {/* Progress line */}
                    <div className="absolute h-1 bg-gray-200 w-full"></div>

                    {/* Step indicators */}
                    {Array.from({ length: totalSteps }, (_, i) => (
                        <div
                            key={i}
                            className={`relative z-10 flex items-center justify-center w-6 h-6 rounded-full 
                                ${
                                    i + 1 <= currentStep
                                        ? "bg-green-500"
                                        : "bg-gray-300"
                                }`}
                        >
                            {/* Optional step number or icon inside the circle */}
                            {i + 1 <= currentStep && (
                                <span
                                    className={`material-symbols-outlined text-white`}
                                >
                                    check
                                </span>
                            )}
                        </div>
                    ))}
                </div>

                {/* Optional step labels */}
                <div className="flex justify-between mt-2 text-xs text-gray-500">
                    <div>Application</div>
                    <div>Personal</div>
                    <div>Education</div>
                    <div>Family</div>
                    <div>Documents</div>
                </div>
            </div>
        );
    };

    return (
        <div className="flex flex-col items-center">
            {/* Progress indicator */}
            <ProgressIndicator />

            {/* Application Details - Step 1 */}
            {currentStep === 1 && (
                <form className="w-[75%] sm:w-[80%] lg:w-[65%] mx-auto">
                    <h2 className="pb-12 font-bold">Application Details</h2>
                    <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-5 sm:gap-4">
                        <div className="block mb-2 relative">
                            <label
                                htmlFor="status"
                                className="absolute top-[-10px] text-gray-600 text-sm"
                            >
                                Status
                            </label>
                            <select
                                id="status"
                                name="status"
                                value={applicationDetails.status}
                                onChange={handleAppDetailsDropDown}
                                placeholder="Status"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                            >
                                <option
                                    value=""
                                    disabled
                                    className="not-italic"
                                >
                                    Select
                                </option>
                                <option value="Old" className="not-italic">
                                    Old
                                </option>
                                <option value="New" className="not-italic">
                                    New
                                </option>
                            </select>
                        </div>
                        <div>
                            <input
                                type="text"
                                name="sy"
                                value={applicationDetails.sy}
                                onChange={handleAppDetailsChange}
                                placeholder="School Year"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="caseNo"
                                value={applicationDetails.caseNo}
                                onChange={handleAppDetailsChange}
                                placeholder="Case Number"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                    </div>
                    <div className="mt-4">
                        <button
                            className="px-5 py-[6px] bg-green-500 text-white rounded-sm shadow-lg"
                            onClick={nextStep}
                        >
                            Next
                        </button>
                    </div>
                </form>
            )}

            {/* Personal Information - Step 2 */}
            {currentStep === 2 && (
                <form className="w-[75%] sm:w-[80%] lg:w-[65%] mx-auto">
                    <h2 className="pb-6 font-bold">Personal Information</h2>
                    <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-5 sm:gap-4">
                        <div>
                            <input
                                type="text"
                                name="lastName"
                                value={personalInfo.lastName}
                                placeholder="Last Name"
                                onChange={handlePersonalInfoChange}
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="firstName"
                                value={personalInfo.firstName}
                                onChange={handlePersonalInfoChange}
                                placeholder="First Name"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="middleName"
                                value={personalInfo.middleName}
                                onChange={handlePersonalInfoChange}
                                placeholder="Middle Name"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>

                        <div className="flex justify-between gap-4">
                            <div className="block w-[50%] mb-2 relative">
                                <label
                                    htmlFor="status"
                                    className="absolute top-[-10px] text-gray-600 text-sm"
                                >
                                    Suffix
                                </label>
                                <select
                                    name="suffix"
                                    value={personalInfo.suffix}
                                    onChange={handlePersonalInfoDropDown}
                                    className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                >
                                    <option value="" disabled>
                                        Select
                                    </option>
                                    <option value="Jr">Jr</option>
                                    <option value="Sr">Sr</option>
                                    <option value="I">I</option>
                                    <option value="II">II</option>
                                    <option value="III">III</option>
                                    <option value="IV">IV</option>
                                </select>
                            </div>

                            <div className="block w-[50%] mb-2 relative">
                                <label
                                    htmlFor="status"
                                    className="absolute top-[-10px] text-gray-600 text-sm"
                                >
                                    Gender
                                </label>
                                <select
                                    name="gender"
                                    value={personalInfo.gender}
                                    onChange={handlePersonalInfoDropDown}
                                    className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                >
                                    <option value="" disabled>
                                        Select
                                    </option>
                                    <option value="Male">Male</option>
                                    <option value="Female">Female</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <input
                                type="text"
                                name="age"
                                value={personalInfo.age}
                                onChange={handlePersonalInfoChange}
                                placeholder="Age"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>

                        <div>
                            <input
                                type="text"
                                name="birthdate"
                                value={personalInfo.birthdate}
                                onChange={handlePersonalInfoChange}
                                placeholder="(mm/dd/yyyy)"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="birthplace"
                                value={personalInfo.birthplace}
                                onChange={handlePersonalInfoChange}
                                placeholder="Birthplace"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="homeAddress"
                                value={personalInfo.homeAddress}
                                onChange={handlePersonalInfoChange}
                                placeholder="Home Address"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="subdivisionVillage"
                                value={personalInfo.subdivisionVillage}
                                onChange={handlePersonalInfoChange}
                                placeholder="Village/Subdivision"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="barangay"
                                value={personalInfo.barangay}
                                onChange={handlePersonalInfoChange}
                                placeholder="Barangay"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="cityMunicipality"
                                value={personalInfo.cityMunicipality}
                                onChange={handlePersonalInfoChange}
                                placeholder="City/Municipality"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="zipcode"
                                value={personalInfo.zipcode}
                                onChange={handlePersonalInfoChange}
                                placeholder="Zipcode"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="personalContact"
                                value={personalInfo.personalContact}
                                onChange={handlePersonalInfoChange}
                                placeholder="Personal Contact"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="secondaryContact"
                                value={personalInfo.secondaryContact}
                                onChange={handlePersonalInfoChange}
                                placeholder="Secondary Contact"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="religion"
                                value={personalInfo.religion}
                                onChange={handlePersonalInfoChange}
                                placeholder="Religion"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="civilStatus"
                                value={personalInfo.civilStatus}
                                onChange={handlePersonalInfoChange}
                                placeholder="Civil Status"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="facebook"
                                value={personalInfo.facebook}
                                onChange={handlePersonalInfoChange}
                                placeholder="Facebook"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="emailAddress"
                                value={personalInfo.emailAddress}
                                onChange={handlePersonalInfoChange}
                                placeholder="Email Address"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                    </div>
                    <div className="mt-5">
                        <button
                            className="p-3 px-5 py-[6px]"
                            onClick={prevStep}
                        >
                            Back
                        </button>
                        <button
                            className="px-5 py-[6px] bg-green-500 text-white rounded-sm shadow-lg"
                            onClick={nextStep}
                        >
                            Next
                        </button>
                    </div>
                </form>
            )}

            {currentStep === 3 && (
                <form className="w-[75%] sm:w-[80%] lg:w-[65%] mx-auto">
                    <h2 className="py-3 font-bold">Educational Background</h2>
                    <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-5 sm:gap-4">
                        <div>
                            <input
                                type="text"
                                name="lastSchoolAttended"
                                value={educationalBackground.lastSchoolAttended}
                                onChange={handleEduBackgroundChange}
                                placeholder="Last School Attended"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="lastSchoolLocation"
                                value={educationalBackground.lastSchoolLocation}
                                onChange={handleAppDetailsChange}
                                placeholder="Location"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="honorAward"
                                value={educationalBackground.honorAward}
                                onChange={handleAppDetailsChange}
                                placeholder="Honor Award"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="gwa"
                                value={educationalBackground.gwa}
                                onChange={handleEduBackgroundChange}
                                placeholder="GWA"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="courseTaken"
                                value={educationalBackground.courseTaken}
                                onChange={handleEduBackgroundChange}
                                placeholder="Course Taken"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>

                        <div className="block mb-2 relative">
                            <label
                                htmlFor="yearLevel"
                                className="absolute top-[-10px] text-gray-600 text-sm"
                            >
                                Incoming Grade/Year Level:
                            </label>
                            <select
                                id="yearLevel"
                                name="incomingGradeYearLevel"
                                value={
                                    educationalBackground.incomingGradeYearLevel
                                }
                                onChange={handleEduBackgroundDropDown}
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                            >
                                <option value="Select" disabled>
                                    Select
                                </option>
                                <option value="JHS">JHS</option>
                                <option value="SHS">SHS</option>
                                <option value="College">College</option>
                                <option value="Vocational">Vocational</option>
                            </select>
                        </div>

                        <div>
                            <input
                                type="text"
                                name="school"
                                value={educationalBackground.school}
                                onChange={handleEduBackgroundChange}
                                placeholder="School"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="newSchoolLocation"
                                value={educationalBackground.newSchoolLocation}
                                onChange={handleEduBackgroundChange}
                                placeholder="Location"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="firstCourse"
                                value={educationalBackground.firstCourse}
                                onChange={handleEduBackgroundChange}
                                placeholder="Course 1"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="secondCourse"
                                value={educationalBackground.secondCourse}
                                onChange={handleEduBackgroundChange}
                                placeholder="Course 2"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                    </div>
                    <div className="mt-4">
                        <button className="px-5 py-[6px]" onClick={prevStep}>
                            Back
                        </button>
                        <button
                            className="px-5 py-[6px] bg-green-500 text-white rounded-sm shadow-lg"
                            onClick={nextStep}
                        >
                            Next
                        </button>
                    </div>
                </form>
            )}

            {currentStep === 4 && (
                <form className="w-[80%] sm:w-[80%] lg:w-[65%] mx-auto">
                    <h2 className="pt-4 pb-6 font-bold">Family Information</h2>
                    <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-5 sm:gap-4">
                        <div>
                            <input
                                type="text"
                                name="fatherName"
                                value={familyInfo.fatherName}
                                onChange={handleFamilyInfoChange}
                                placeholder="Name of Father"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="fatherAge"
                                value={familyInfo.fatherAge}
                                onChange={handleFamilyInfoChange}
                                placeholder="Age"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="fatherEduAttainment"
                                value={familyInfo.fatherEduAttainment}
                                onChange={handleFamilyInfoChange}
                                placeholder="Educational Attainment"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="fatherOccupation"
                                value={familyInfo.fatherOccupation}
                                onChange={handleFamilyInfoChange}
                                placeholder="Occupation"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="fatherMonthlyIncome"
                                value={familyInfo.fatherMonthlyIncome}
                                onChange={handleFamilyInfoChange}
                                placeholder="Monthly Income"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="fatherContactNumber"
                                value={familyInfo.fatherContactNumber}
                                onChange={handleFamilyInfoChange}
                                placeholder="Contact Number"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>

                        <div>
                            <input
                                type="text"
                                name="motherName"
                                value={familyInfo.motherName}
                                onChange={handleFamilyInfoChange}
                                placeholder="Name of Mother"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="motherAge"
                                value={familyInfo.motherAge}
                                onChange={handleFamilyInfoChange}
                                placeholder="Age"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="motherEduAttainment"
                                value={familyInfo.motherEduAttainment}
                                onChange={handleFamilyInfoChange}
                                placeholder="Educational Attainment"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="motherOccupation"
                                value={familyInfo.motherOccupation}
                                onChange={handleFamilyInfoChange}
                                placeholder="Occupation"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="motherMonthlyIncome"
                                value={familyInfo.motherMonthlyIncome}
                                onChange={handleFamilyInfoChange}
                                placeholder="Monthly Income"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="motherContactNumber"
                                value={familyInfo.motherContactNumber}
                                onChange={handleFamilyInfoChange}
                                placeholder="Contact Number"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>

                        <div>
                            <input
                                type="text"
                                name="guardianName"
                                value={familyInfo.guardianName}
                                onChange={handleFamilyInfoChange}
                                placeholder="Guardian Name"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="guardianAge"
                                value={familyInfo.guardianAge}
                                onChange={handleFamilyInfoChange}
                                placeholder="Age"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="guardianEduAttainment"
                                value={familyInfo.guardianEduAttainment}
                                onChange={handleFamilyInfoChange}
                                placeholder="Educational Attainment"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="guardianOccupation"
                                value={familyInfo.guardianOccupation}
                                onChange={handleFamilyInfoChange}
                                placeholder="Occupation"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="guardianMonthlyIncome"
                                value={familyInfo.guardianMonthlyIncome}
                                onChange={handleFamilyInfoChange}
                                placeholder="Monthly Income"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="guardianContactNumber"
                                value={familyInfo.guardianContactNumber}
                                onChange={handleFamilyInfoChange}
                                placeholder="Contact Number"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                    </div>

                    <h2 className="py-10 font-bold">
                        Contact Person In Case of Emergency
                    </h2>
                    <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-5 sm:gap-4">
                        <div>
                            <input
                                type="text"
                                name="name"
                                value={contactPerson.name}
                                onChange={handleContactPersonChange}
                                placeholder="Name"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="relationship"
                                value={contactPerson.relationship}
                                onChange={handleContactPersonChange}
                                placeholder="Relationship"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="address"
                                value={contactPerson.address}
                                onChange={handleContactPersonChange}
                                placeholder="Address"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                        <div>
                            <input
                                type="text"
                                name="contactNo"
                                value={contactPerson.contactNo}
                                onChange={handleContactPersonChange}
                                placeholder="Contact Number"
                                className="w-full outline-none border-b-[2px] border-gray-400 py-2 mt-1 box-border hover:border-black focus:border-green-500"
                                required
                            />
                        </div>
                    </div>
                    <div>
                        <FamilyList />
                    </div>
                    <div className="mt-4">
                        <button className="px-5 py-[6px]" onClick={prevStep}>
                            Back
                        </button>
                        <button
                            className="px-5 py-[6px] bg-green-500 text-white rounded-sm shadow-lg"
                            onClick={nextStep}
                        >
                            Next
                        </button>
                    </div>
                </form>
            )}

            {/* Placeholder for remaining steps (3-5) */}
            {currentStep > 4 && (
                <div className="w-[80%] lg:w-[65%] mx-auto">
                    <h2 className="pl-5 py-3 font-bold">
                        Step {currentStep} Content
                    </h2>
                    <div className="border-l-[1px] pl-7 border-gray-800 py-10">
                        <p>This is a placeholder for Step {currentStep}</p>
                        <p>You can add your form fields for this step here.</p>
                    </div>
                    <div className="mt-4">
                        <button className="p-3" onClick={prevStep}>
                            Back
                        </button>
                        {currentStep < totalSteps ? (
                            <button
                                className="px-5 py-[6px] bg-green-500 text-white rounded-sm shadow-lg"
                                onClick={nextStep}
                            >
                                Next
                            </button>
                        ) : (
                            <button
                                className="px-5 py-[6px] bg-green-500 text-white rounded-sm shadow-lg"
                                onClick={handleSubmit}
                            >
                                Submit
                            </button>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}

export default ApplicationForm;
