import Accordion from "./pages/Home/Accordion";
import NavBar from "./components/NavBar";

import AdminLayout from "./components/Layout/AdminLayout";
import ScholarLayout from "./components/Layout/ScholarLayout";
import StaffLayout from "./components/Layout/StaffLayout";
import HomePageLayout from "./components/Layout/HomePageLayout";

export function App() {
    return (
    // <HomePageLayout />
        //  <ScholarLayout />
        // <AdminLayout />
        <StaffLayout />
    );
}