import Dashboard from "../../pages/Scholar/Dashboard";
import SideBar from "../../pages/Scholar/SideBar";
import TopBar from "../../pages/Scholar/TopBar";

const items = [
    {
        text: "User Accounts",
        iconName: "manage_accounts",
        iconStyle: "text-[1.1rem]",
    },
    {
        text: "Settings",
        iconName: "settings",
        iconStyle: "text-[1.1rem]",
    },
    {
        text: "Activity",
        iconName: "upload_file",
        iconStyle: "text-[1.1rem]",
    },
    {
        text: "Logout",
        style: "mt-auto",
        iconName: "logout",
        iconStyle: "text-[1.1rem]",
    },
];

const overviewData = [
    {
        title: "Active Accounts",
        status: "300 Accounts",
        color: "bg-green-400 text-gray-900",
        icon: "person",
        iconColor: "text-green-600",
        iconBackground: "bg-green-100",
    },
    {
        title: "Deactivated Accounts",
        status: "6",
        color: "bg-yellow-400 text-gray-900",
        icon: "person_off",
        iconColor: "text-yellow-600",
        iconBackground: "bg-yellow-100",
    },
];

export default function AdminLayout() {
    return (
        <div className="">
            <TopBar />
            <div className="flex justify-center">
                <SideBar items={items} />
                <div className="w-full h-[90vh] overflow-y-scroll scroll-smooth">
                <Dashboard overviewData={overviewData} />
                </div>
            </div>
        </div>
    );
}
