import Dashboard from "../../pages/Scholar/Dashboard";
import SideBar from "../../pages/Scholar/SideBar";
import TopBar from "../../pages/Scholar/TopBar";
import StaffSideBar from "../../pages/Staff/StaffSideBar";

const sidebarItems = [
    {
        text: "Dashboard",
        iconName: "dashboard",
    },
    {
        text: "Scholarship",
        iconName: "school",
        subItems: [
            "Manage info",
            "Set requirements",
            "Update documents",
            "Set criteria",
            "Set deadlines",
        ],
    },
    {
        text: "Records",
        iconName: "folder_shared",
        subItems: [
            "View records",
            "Edit/Delete info",
            "View applications",
            "Validate docs",
        ],
    },
    {
        text: "Applications",
        iconName: "checklist",
        subItems: ["Validate apps", "Approve/Reject"],
    },
    {
        text: "Events & Duty",
        iconName: "event",
        subItems: ["Set events", "Log duty hours"],
    },
    {
        text: "Logout",
        style: "mt-auto",
        iconName: "logout",
        iconStyle: "text-[1.1rem]",
    },
];

const overviewData = [
    {
        title: "Active Accounts",
        status: "100 Accounts",
        color: "bg-green-400 text-gray-900",
        icon: "person",
        iconColor: "text-green-600",
        iconBackground: "bg-green-100",
    },
    {
        title: "Deactivated Accounts",
        status: "6",
        color: "bg-yellow-400 text-gray-900",
        icon: "person_off",
        iconColor: "text-yellow-600",
        iconBackground: "bg-yellow-100",
    },
];

export default function StaffLayout() {
    return (
        <div className="">
            <TopBar />
            <div className="flex justify-center">
                <StaffSideBar items={sidebarItems} />
                <div className="w-full h-[90vh] overflow-y-scroll scroll-smooth">
                    {/* <Dashboard overviewData={overviewData} /> */}
                </div>
            </div>
        </div>
    );
}
