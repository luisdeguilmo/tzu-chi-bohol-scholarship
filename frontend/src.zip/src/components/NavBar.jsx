import { useNavigate } from "react-router-dom";
import Logo from "/src/assets/tzu_chi_logo.png";

function NavLinks() {
    const navigate = useNavigate();

    return (
        <ul className="flex gap-4 items-center text-sm font-semibold">
            <li>
                <a href="">About Scholarship</a>
            </li>
            <li>
                <a href="">How to apply</a>
            </li>
            <li>
                <a href="">Contact</a>
            </li>
            <button
                onClick={() => navigate("/application")}
                className="w-28 p-2 text-white bg-green-600 rounded-sm"
            >
                Apply Now
            </button>
        </ul>
    );
}

function NavBar() {
    return (
        <header className="flex items-center justify-between border-b-[2px] p-4 pr-4">
            <div className="flex items-center">
                <img className="w-12" src={Logo} alt="Tzu Chi Logo" />
                <div>
                    <p className="mb-[-8px] font-bold whitespace-nowrap">
                        Tzu Chi Foundation
                    </p>
                    <p className="text-sm whitespace-nowrap">
                        Information Management System
                    </p>
                </div>
            </div>
            <nav className="hidden md:block">
                <NavLinks />
            </nav>
            <div className="flex flex-col gap-1 md:hidden">
                <span className="block w-5 h-[2.5px] bg-slate-600"></span>
                <span className="block w-5 h-[2px] bg-slate-600"></span>
                <span className="block w-5 h-[2.5px] bg-slate-600"></span>
            </div>
        </header>
    );
}

export default NavBar;
